
package com.example.consumer.service;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class ConsumerService {

	@KafkaListener(topics = "${app.topic.name}", groupId = "my-group")
	public void consume(String message) {
		System.out.println("Received Message: " + message);
	}
}
