
package com.example.producer.controller;

import com.example.producer.service.ProducerService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/producer")
public class ProducerController {

    private final ProducerService producerService;

    public ProducerController(ProducerService producerService) {
        this.producerService = producerService;
    }

    @PostMapping("/{message}")
    public String sendMessage(@PathVariable String message) {
        producerService.sendMessage(message);
        return "Message Sent Successfully!";
    }
}
